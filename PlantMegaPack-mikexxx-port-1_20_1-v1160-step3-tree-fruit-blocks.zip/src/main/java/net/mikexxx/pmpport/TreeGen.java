package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

/** Very small generic tree builder: straight trunk + round or conical crown. */
public final class TreeGen {
    private TreeGen() {}

    private static boolean free(BlockState s) {
        return s.isAir() || s.canBeReplaced() || s.is(BlockTags.LEAVES);
    }

    public static boolean grow(ServerLevel lv, BlockPos pos, Block log, Block leaf, boolean conifer, int baseH, RandomSource r) {
        int h = baseH + r.nextInt(3);
        for (int y = 1; y <= h + 1; y++) if (!free(lv.getBlockState(pos.above(y)))) return false;
        BlockState logS = log.defaultBlockState();
        BlockState leafS = leaf.defaultBlockState();
        // naturally grown leaves are NOT persistent: they decay when no log is near (distance is corrected by a scheduled tick)
        if (leafS.hasProperty(LeavesBlock.PERSISTENT)) leafS = leafS.setValue(LeavesBlock.PERSISTENT, false);
        if (leafS.hasProperty(LeavesBlock.DISTANCE)) leafS = leafS.setValue(LeavesBlock.DISTANCE, 6);
        for (int y = 0; y < h; y++) lv.setBlock(pos.above(y), logS, 3);
        if (conifer) {
            for (int y = h; y >= 2; y--) {
                int rad = Math.min(3, (h - y + 1) / 2);
                put(lv, pos.above(y), rad, leafS, r, rad > 1);
            }
            lv.setBlock(pos.above(h), leafS, 3);
            lv.setBlock(pos.above(h + 1), leafS, 3);
            lv.scheduleTick(pos.above(h), leafS.getBlock(), 1);
            lv.scheduleTick(pos.above(h + 1), leafS.getBlock(), 1);
        } else {
            for (int y = h - 3; y <= h + 1; y++) {
                int rad = y >= h ? 1 : 2;
                put(lv, pos.above(y), rad, leafS, r, rad == 2);
            }
            fruit(lv, pos, h, log, leaf);
        }
        return true;
    }

    /** fruit / nut trees: 4 branch logs under the crown, a ripe fruit block hangs below each one (like 1.12.2) */
    private static void fruit(ServerLevel lv, BlockPos pos, int h, Block log, Block leaf) {
        ResourceLocation k = ForgeRegistries.BLOCKS.getKey(leaf);
        if (k == null || !k.getPath().startsWith("leave_") || h < 4) return;
        Block fb = ForgeRegistries.BLOCKS.getValue(new ResourceLocation(k.getNamespace(), "trfrt_" + k.getPath().substring(6)));
        if (!(fb instanceof TreeFruitBlock)) return;
        BlockState fs = fb.defaultBlockState().setValue(TreeFruitBlock.AGE, 7);
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos bp = pos.above(h - 3).relative(d);
            BlockPos fp = bp.below();
            BlockState cur = lv.getBlockState(fp);
            if (!(cur.isAir() || cur.canBeReplaced())) continue;
            BlockState ls = log.defaultBlockState();
            if (ls.hasProperty(RotatedPillarBlock.AXIS)) ls = ls.setValue(RotatedPillarBlock.AXIS, d.getAxis());
            lv.setBlock(bp, ls, 3);
            lv.setBlock(fp, fs, 3);
        }
    }

    private static void put(ServerLevel lv, BlockPos c, int rad, BlockState leafS, RandomSource r, boolean trimCorners) {
        for (int dx = -rad; dx <= rad; dx++)
            for (int dz = -rad; dz <= rad; dz++) {
                if (trimCorners && Math.abs(dx) == rad && Math.abs(dz) == rad && r.nextBoolean()) continue;
                BlockPos p = c.offset(dx, 0, dz);
                BlockState cur = lv.getBlockState(p);
                if (cur.isAir() || cur.canBeReplaced() || cur.is(BlockTags.LEAVES)) {
                    lv.setBlock(p, leafS, 3);
                    lv.scheduleTick(p, leafS.getBlock(), 1);
                }
            }
    }
}
