package net.mikexxx.pmpport;

import net.minecraft.util.Mth;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/**
 * Dwarf Palmetto: the original mod rendered it as ONE flat plane (render type FLAT) instead of a crossed plant.
 * The plane is turned to face the player when placed (8 angles in 22.5 degree steps, a plane is two sided).
 */
public class PalmettoBlock extends PlantBlock {
    public static final IntegerProperty ROT = IntegerProperty.create("rot", 0, 7);

    public PalmettoBlock(Properties props, int maxStage) {
        super(props, maxStage, Type.GROUND);
        this.registerDefaultState(this.defaultBlockState().setValue(ROT, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        super.createBlockStateDefinition(b);
        b.add(ROT);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        int rot = Mth.floor(ctx.getRotation() / 22.5F + 0.5F) & 7;
        return this.defaultBlockState().setValue(ROT, rot);
    }
}
